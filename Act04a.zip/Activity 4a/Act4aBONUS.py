def doStuff(picture):
  width = getWidth(picture)
  halfWidth = width/2
  pixels=getPixels(picture)
  setColor(pixels[halfWidth-3], yellow)
  setColor(pixels[halfWidth-2], yellow)
  setColor(pixels[halfWidth-1], yellow)
  setColor(pixels[halfWidth], yellow)
  setColor(pixels[halfWidth+1], yellow)
  setColor(pixels[halfWidth+2], yellow)
  setColor(pixels[width + halfWidth -3], yellow)
  setColor(pixels[width + halfWidth +2], yellow)
  setColor(pixels[width * 2 + halfWidth -3], yellow)
  setColor(pixels[width * 2 + halfWidth +2], yellow)
  setColor(pixels[width * 3 + halfWidth -3], yellow)
  setColor(pixels[width * 3 + halfWidth +2], yellow)
  setColor(pixels[width * 4 + halfWidth -3], yellow)
  setColor(pixels[width * 4 + halfWidth +2], yellow)
  setColor(pixels[width * 5 + halfWidth -3], yellow)
  setColor(pixels[width * 5 + halfWidth -2], yellow)
  setColor(pixels[width * 5 + halfWidth -1], yellow)
  setColor(pixels[width * 5 + halfWidth ], yellow)
  setColor(pixels[width * 5 + halfWidth +1], yellow)
  setColor(pixels[width * 5 + halfWidth +2], yellow)
  show(picture)
 
def tintcolor(picture):
  pixels=getPixels(picture)
  for p in pixels:
    blueValue = getBlue(p)
    setBlue(p, blueValue * .25)
  repaint(picture)
  
def main(picture):
  doStuff(picture)
  tintcolor(picture)