def doStuff(picture):
  width = getWidth(picture)
  pixels=getPixels(picture)
  setColor(pixels[0], yellow)
  setColor(pixels[1], yellow)
  setColor(pixels[2], yellow)
  setColor(pixels[3], yellow)
  setColor(pixels[4], yellow)
  setColor(pixels[5], yellow)
  setColor(pixels[width], yellow)
  setColor(pixels[width + 5], yellow)
  setColor(pixels[width * 2], yellow)
  setColor(pixels[width * 2 + 5], yellow)
  setColor(pixels[width * 3], yellow)
  setColor(pixels[width * 3 + 5], yellow)
  setColor(pixels[width * 4], yellow)
  setColor(pixels[width * 4 + 5], yellow)
  setColor(pixels[width * 5], yellow)
  setColor(pixels[width * 5 + 1], yellow)
  setColor(pixels[width * 5 + 2], yellow)
  setColor(pixels[width * 5 + 3], yellow)
  setColor(pixels[width * 5 + 4], yellow)
  setColor(pixels[width * 5 + 5], yellow)
  show(picture)
 
def tintcolor(picture):
  pixels=getPixels(picture)
  for p in pixels:
    blueValue = getBlue(p)
    setBlue(p, blueValue * .25)
  repaint(picture)
  
def main(picture):
  doStuff(picture)
  tintcolor(picture)

 
