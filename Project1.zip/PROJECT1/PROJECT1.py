#joseph Culp 09/28/2023
def spreadpics(barnum):
  #line 4-10 are creating resources used through function
  picture1 = makePicture(pickAFile())
  picture2 = makePicture(pickAFile())
  picwidth1 = getWidth(picture1)
  picwidth2 = getWidth(picture2)
  barwidth1 = getWidth(picture1)/barnum
  barwidth2 = getWidth(picture2)/barnum
  canvas = makeEmptyPicture(picwidth1+picwidth2,getHeight(picture1))
  #for loop that copies and spreads proportional slices across canvas
  for slice in range(0,barnum):
    copySlice(barwidth1*slice,barwidth1*(slice+1),(barwidth1*slice) + (barwidth2*slice),picture1,canvas)
    #leaves room for "even" bars while making "odd" bars
    copySlice(barwidth2*slice,barwidth2*(slice+1),(barwidth1*(slice+1)) + (barwidth2*slice),picture2,canvas)
    #vice versa
  explore(canvas)
  
def copySlice(startX,endX,targetx,picture,canvas):
  for x in range(startX, endX):
    for y in range(0, getHeight(picture)):
      color = getColor(getPixel(picture,x,y))
      setColor(getPixel(canvas,targetx,y),color)
    #targetx runs through the x coordinates artifically via number counter
    targetx = targetx + 1


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
