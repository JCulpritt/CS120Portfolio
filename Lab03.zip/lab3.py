def grayscale(pic):
  pixels = getPixels(pic)
  for p in pixels:
    intensity = (getRed(p) + getGreen(p) + getBlue(p))/3
    setColor(p, makeColor(intensity, intensity, intensity))
  show(pic)
  
def colorAverage(pic):
  pixels = getPixels(pic)
  for p in pixels:
    setColor(p, makeColor((getRed(p) + 127) / 2, (getGreen(p) + 181)/2, (getBlue(p) + 63)/2))
  show(pic)
  
def swap(pic):
  pixels = getPixels(pic)
  for p in pixels:
     red = getRed(p)
     green = getGreen(p)
     blue = getBlue(p)
     newred = blue
     newblue = green
     newgreen = red
     setColor(p,makeColor(newred, newblue, newgreen))
  show(pic)

def all():
 pic = makePicture(pickAFile())
 show(pic)
 colorAverage(pic)
 repaint(pic)
 swap(pic)
 repaint(pic)
 grayscale(pic)
 repaint(pic)