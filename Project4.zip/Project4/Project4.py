#12/08/2023
#Joseph Aslan Culp
def adventure():
  global end_flag, turn_limit, map, username
  init()
  location = "porch" 
  showIntro()
  moves = ["north","east","south","west"]
  command = ""
  score = str(turn_limit)
  if username == "Operator123":
    devExit()
  while (command != "quit" and end_flag == False):
    changemap(location)
    showInformation(str(showRoom(location)))
    #printNow(str(showRoom(location)))  

    command = requestString("What would you like to do? (type 'help' for valid commands)").lower()
    if command in moves:
      printNow("You chose: " + command)   
      location1 = location
      location = pickRoom(command,location)
      if location == "invalid option. Pick Again":
        showInformation(location)
        location = location1
      if location == "kitchen":
        flag = checklock()
        if flag == False:
          location = location1
          continue
      score = end(location)
    elif command == "grab":
      pickUpQuestions(location)
      score = end(location)
    elif command == "use":
      if location == "living room":
        lightfire()
      elif location == "upper hall":
        unlockroom()
      elif location == "bath":
        fillbottle()
      else:
        showInformation("nothing to use here!")
        continue
      score = end(location)
    elif command == "drop":
      dropitem(location)
      score = end(location)
    elif command == "inventory":
      inven()
    elif command == "exits":
      showInformation(str(showRoom(location,1)))
    elif command == "score":
      showInformation("Your Current Score: " + score)
    elif command == "scoreboard":
      scoreboard()
    elif command == "help":
      showInformation('Type single word commands, no need to describe the subject. For example, "grab key" should just be "grab" or "use key" should just be "use"\nCommands: north, south, east, west, grab, inventory, use, exits, score, scoreboard, help, and quit.')
    elif command == "quit":
      printNow("Thank you for playing!")
      continue
    else:
      showInformation("Invalid option. Pick Again")
        
def init(): #INITILIZATION
  global username, map, porch_count, porch, hall_count, hall, dining_count, dining, living_count, living, upper_count, upper, kitchen_count, kitchen, kitchen_unlock, bath_count, bath, bed_count, bed, patio_count, patio, end_flag, player, fire, firelist, turns, turn_limit, room_dict
  username = requestString("Please enter your username:").title()
  porch_count = 0
  porch = []
  hall_count = 0
  hall = []
  dining_count = 0
  dining = ["empty bottle"]
  living_count = 0
  living = ["pages"]
  upper_count = 0
  upper = []
  kitchen_count = 0
  kitchen = ["matches", "food"]
  kitchen_unlock = False
  bath_count = 0
  bath = []
  bed_count = 0
  bed = ["key"]
  patio_count = 0
  patio = ["firewood"]
  end_flag = False
  player = []
  fire = False
  firelist = []
  turns = 0 
  turn_limit = 50
  room_dict = {"porch":porch, "hall":hall, "dining room":dining, "living room":living, "upper hall": upper, "kitchen": kitchen, "bath":bath, "bedroom":bed, "patio":patio}
  map = makePicture(getMediaPath("FloorPlan.jpeg"))
  C_map = makePicture(getMediaPath("C_FloorPlan.jpeg"))
  score = str((turn_limit - turns) + player.count("Dave Da Dapper Duck") * 5)
  
def end(location): #TESTS AND DEALS WITH END OF GAME
  global end_flag, player, fire, turns, turn_limit, username, score
  score = str((turn_limit - turns) + player.count("Dave Da Dapper Duck") * 5)
  while turns <= turn_limit:
    if "food" in player and "water" in player and fire == True and location == "living room":
     end_flag = True
     showlocation(location)
     showInformation("With the fire to warm you, the canned food for sustenence, and the bath water for hydration: \nYou were able to survive long enough to wait out the blizzard\n Congratulations you win!!!! With a grand total of " + score + " points!!!")
     writeScore(username + ":" + score)
     return score
    else:
      turns += 1
      score = str((turn_limit - turns) + player.count("Dave Da Dapper Duck") * 5)
      return score
  end_flag = True
  showInformation("SORRY " + username + ", YOU FROZE TO DEATH...\nbetter luck next time :(\nScore: " + score)
  writeScore(username + ":score\n")
  
def showIntro(): 
  printNow("Hello! Welcome to 'Warmth'! A game of Survival!")
  printNow("Your goal is to fit yourself with everything you need to survive")
  printNow("Use 'North', 'South', 'East', and 'West' to move around, and use 'help' to recieve a full list of commands available!")
  printNow("You may also use 'quit' to quit the game at anytime. ENJOY!!!")
  printNow("--------------------------------------------------")#For clarity in text area
  printNow("AFTER GETTING LOST DURING A MOUNTAIN HIKING TRIP IN NORTHERN CANADA, YOU FIND YOURSELF LOST WITH A BLIZZARD COMING IN!!")
  printNow("TEMPERATURES ARE DROPPING, AND THE COLD IS BECOMING UNBEARABLE AND DANGEROUS. LUCKILY YOU STUMBLE UPON AN ABANDONED CABIN IN THE MOUNTAINS")
  printNow("WILL YOU BE ABLE TO SURVIVE THIS HARSH BLIZZARD? ONLY YOU CAN FIND OUT!!")
  printNow("--------------------------------------------------")

#----------------MOVEMENT FUNCTIONS-----------------------
def pickRoom(direction,room):
  #Porch
  if room == "porch":
    if direction == "north":
      return "hall"
    else:
      return "invalid option. Pick Again"
  #breaking hall into 'Upper Hall' and just 'Hall'
  if room == "hall":
    if direction == "north":
      return "upper hall"
    elif direction == "east":
      return "dining room"
    elif direction == "west": 
      return "living room" 
    elif direction == "south":
      return "porch"
    else:
      return "invalid option. Pick Again"
  #Here is the 'Upper Hall' 
  if room == "upper hall": 
    if direction == "west":
      return "bedroom"
    elif direction == "east":
      return "kitchen"
    elif direction == "north":
      return "bath"
    elif direction == "south":
      return "hall"
    else:
      return "invalid option. Pick Again" 
  #Living Room  
  if room == "living room":
    if direction == "east": 
      return "hall"
    else:
      return "invalid option. Pick Again"
  #Dining Room 
  if room == "dining room":
    if direction == "west":
      return "hall" 
    else:
      return "invalid option. Pick Again"
  #Bedroom 
  if room == "bedroom":
    if direction == "east":
      return "upper hall"
    elif direction == "north":
      return "patio"
    else:
      return "invalid option. Pick Again"
  #Kitchen
  if room == "kitchen":
    if direction == "west":
      return "upper hall"
    else:
      return "invalid option. Pick Again"
  #Bathroom 
  if room == "bath":
    if direction == "south":
      return "upper hall"   
    else:
      return "invalid option. Pick Again"
  #Final One, Patio 
  if room == "patio":
    if direction == "south":
      return "bedroom"
    else:
      return "invalid option. Pick Again"


def showRoom(room, set = 0): #This function gives a small blurb about the area for effect.
  global fire, porch_count, hall_count, dining_count, living_count, upper_count, kitchen_count, bath_count, bed_count, patio_count, player, porch, hall, dining, living, upper, kicthen, bath, bed, patio
  other = " Also there are other item(s) scattered throughout the room\n"
  if room == "porch":
    string = "You are on the Porch. It's cold, better find warmth fast!\nPossible Movements: North"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    porch_count += 1
    if porch_count == 1:
      blockingPlay(makeSound(getMediaPath("porch.wav")))
    if len(porch) > 0:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "hall":
    string = "You are now in the Hall.\nPossible Movements: North, East, West, and South"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    hall_count += 1
    if hall_count == 1:
      blockingPlay(makeSound(getMediaPath("hall.wav")))
      string = string.split("\n")
      string = string[0] + " It's warmer in here, but not by much.\n" + string[1]
    if len(hall) > 0:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "upper hall":
    string = "You are now in the Upper Hall.\nPossible Movements: North, East, West, and South"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    upper_count += 1
    if upper_count == 1:
      blockingPlay(makeSound(getMediaPath("upper.wav")))
    if len(upper) > 0:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "living room":
    string = "You are now in the Living Room, there is a fireplace here.\nPossible Movements: East" 
    if set == 1:
      string = string.split('\n')
      return(string[1])
    living_count += 1
    if living_count == 1:
      blockingPlay(makeSound(getMediaPath("living.wav")))
      string = "Old books flitter in the cold wind coming from the empty fireplace. The pages of the books may be good fire starter... " + string
    elif "pages" in living:
        string = "The pages of these books may be a good fire starter... " + string 
    if len(porch) > 1:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "bedroom":
    string = "You are now in the Bedroom. \nPossible Movements: North and East"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    bed_count += 1
    if bed_count == 1:
      blockingPlay(makeSound(getMediaPath("bed.wav")))
    if "key" in bed:
      string = "There is a shiny object underneath the bed." + string
    if len(bed) > 1:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "bath":
    string = "You are now in the Bathroom. There is a bathtub filled with cold off-white water\nPossible Movements: South"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    bath_count += 1
    if bath_count == 1:
      blockingPlay(makeSound(getMediaPath("bath.wav")))
      string = "A small fly shoots past you out of the dingy bathroom. " + string
    if len(player) == 5:
      string = "There's an odd looking rubber duck floating in the water. " + string
      bath.append("Dave Da Dapper Duck")
      if len(bath) > 1:
        string = string.split("\n")
        string = string[0] + other + string[1]
    elif len(bath) > 0:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "kitchen":
    string = "You are now in the Kitchen.\nPossible Movements: West"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    kitchen_count += 1
    if kitchen_count == 1:
      blockingPlay(makeSound(getMediaPath("kitchen.wav")))
      string = "There was a metal cart infront of the door stocked with canned food. There's a match book on top. " + string
    elif "food" in kitchen and "matches" not in kitchen:
        string = string.split("\n")
        if len(kitchen) > 1:
            string = string[0] + " There is canned food stocked in the metal cart. " + other + string[1]
            return(string)
        string = string[0] + " There is canned food stocked in the metal cart.\n" + string[1]
    elif "matches" in kitchen and "food" not in kitchen:
        string = string.split("\n")
        if len(kitchen) > 1:
            string = string[0] + " There is a book of matches on top of the metal cart. Also there are other item(s) scattered throughout the room\n" + string[1]
            return(string)
        string = string[0] + " There is a book of matches on top of the metal cart.\n" + string[1]
    return(string)
    
  if room == "dining room":
    string = "You are now in the Dining Room.\nPossible Movements: West"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    dining_count += 1
    if dining_count == 1:
      blockingPlay(makeSound(getMediaPath("dining.wav")))
      string = "As you open the door, an old clock chimes, then breaks suddenly. " + string
    if "empty bottle" in dining:
    
        string = string.split("\n")
        string = string[0] + " There is a empty bottle on the old dining table.\n" + string[1]
    if len(dining) > 1:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)
    
  if room == "patio":
    string = "You are now in the Patio area.\nPossible Movements: South"
    if set == 1:
      string = string.split('\n')
      return(string[1])
    patio_count += 1
    if patio_count == 1:
        blockingPlay(makeSound(getMediaPath("patio.wav")))
        string = "Brrr it's cold out!! " + string
    if "firewood" in patio:
        string = string.split("\n")
        string = string[0] + "There is a stack of dry fire wood neatly sitting against the house. \n" + string[1]
    if len(patio) > 1:
        string = string.split("\n")
        string = string[0] + other + string[1]
    return(string)

#-------------NONMOVEMENT COMMANDS-------------------------------
def pickUpQuestions(room):
  global porch, hall, dining, living, upper, kitchen, bath, bed, patio, player, room_dict
  for item in room_dict[room]: 
    question = requestString("Do you want to pick up the " + item).lower()
    if question == "yes":
      player.append(item)
      room_dict[room].remove(item)
      printNow(item + " has been added to the inventory")

def dropitem(room):
  global porch, hall, dining, living, upper, kitchen, bath, bed, patio, player, room_dict
  for item in player:
    question = requestString("Do you want to drop the " + item).lower()
    if question == "yes":
      if item == "Dave Da Dapper Duck":
        showInformation("Why would you drop this? Don't be silly...")
        break
      room_dict[room].append(item)
      player.remove(item)
      printNow(item + " has been dropped in the " + room)

def lightfire():
  global player, fire, firelist
  if "pages" not in player and "firewood" not in player:
    showInformation("nothing to be used here!")
    return

  if "pages" in player:
    question = requestString("Would you like to put the pages in the fireplace?").lower()
    if question == "yes":
      player.remove("pages")
      firelist.append("pages")

  if "firewood" in player:
    question = requestString("Would you like to put the firewood in the fireplace?").lower()
    if question == "yes":
      player.remove("firewood")
      firelist.append("firewood")

  if "pages" in firelist and "firewood" in firelist:
    if "matches" in player:
      question = requestString("Would you like to use your matches to light the fire?").lower()
      if question == "yes":
        player.remove("matches")
        fire = True

def unlockroom():
  global player, kitchen_unlock
  if "key" in player:
    question = requestString("Would you like to unlock the kitchen door with your key?").lower()
    if question == "yes":
      kitchen_unlock = True
      blockingPlay(makeSound(getMediaPath("unlockdoor.wav")))
      showInformation("The Door is now unlocked, but your key broke")
      player.remove("key")
  else:
    showInformation("nothing to be used here!")

#-------SUPPORT FUNCTION-------------
def checklock():
  global kitchen_unlock
  if kitchen_unlock == False:
    showInformation("The Kitchen Door is locked. It seems to need a small key")
    blockingPlay(makeSound(getMediaPath("locked.wav")))
    return False
  else:
    return True
#---------------------------------------    
    
def fillbottle():
  global player
  if "empty bottle" in player:
    question = requestString("Would you like to fill your empty water with the bath water?").lower()
    if question == "yes":
      blockingPlay(makeSound(getMediaPath("waterpour.wav")))
      player.remove("empty bottle")
      player.append("water")
  else:
    showInformation("nothing to be used here!")

def inven():
  global player
  string = "These are the items in your inventory:\n"
  for item in player:
    string = string + "-" + item + "\n"
  showInformation(string)
  
def scoreboard():
  scoreboard = getMediaPath("scoreboard.txt")
  file = open(scoreboard,"rt")
  scores = file.read()
  file.close()
  showInformation(scores)

#-------------------------------------------------------
  
#--------------------EDIT MAP--------------------------
def showlocation(room):
  global map, fire
  file = room + ".jpg"
  if room == "living room":
    if fire == False:
      file = "living room_unlit.jpg"
  source = makePicture(getMediaPath(file))
  for x in range(0, getWidth(source)):
    for y in range(0, getHeight(source)):
      color = getColor(getPixel(source,x,y))
      setColor(getPixel(map, x + 530, y + 375), color)
  repaint(map)

def clearlocation(room):
  global map
  file = room + ".jpg"
  source = makePicture(getMediaPath(file))
  for x in range(0, getWidth(source)):
    for y in range(0, getHeight(source)):
      setColor(getPixel(map, x + 530, y + 375), white)
      
def playerMarker(location):
  global map
  source = makePicture(getMediaPath("playermarker.jpg"))
  if location == "porch":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 365, y + 465), color)
  elif location == "hall":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 365, y + 365), color)
  elif location == "dining room":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 440, y + 375), color)
  elif location == "living room":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 255, y + 375), color)
  elif location == "upper hall":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 370, y + 300), color)
  elif location == "bedroom":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 265, y + 220), color)
  elif location == "bath":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 370, y + 167), color)
  elif location == "kitchen":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 435, y + 215), color)
  elif location == "patio":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 410, y + 125), color)
    
  repaint(map)

def clearPlayerMarker(location):
  global map
  color = white
  source = makePicture(getMediaPath("playermarker.jpg"))
  if location == "porch":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 365, y + 465), color)
  elif location == "hall":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 365, y + 365), color)
  elif location == "dining room":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 440, y + 375), color)
  elif location == "living room":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 255, y + 375), color)
  elif location == "upper hall":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 370, y + 300), color)
  elif location == "bedroom":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 265, y + 220), color)
  elif location == "bath":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 370, y + 167), color)
  elif location == "kitchen":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 435, y + 215), color)
  elif location == "patio":
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 410, y + 125), color)
        
def showItems():
  global map, player
  if "firewood" in player:
    source = makePicture(getMediaPath("firewood.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 525, y + 125), color)
  if "food" in player:
    source = makePicture(getMediaPath("food.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 600, y + 125), color)
  if "empty bottle" in player:
    source = makePicture(getMediaPath("empty bottle.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 675, y + 125), color)
  if "water" in player:
    source = makePicture(getMediaPath("water.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 750, y + 125), color)
  if "matches" in player:
    source = makePicture(getMediaPath("matches.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 525, y + 175), color)
  if "key" in player:
    source = makePicture(getMediaPath("key.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 600, y + 175), color)
  if "pages" in player:
    source = makePicture(getMediaPath("pages.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 675, y + 175), color)
  if "Dave Da Dapper Duck" in player:      
    source = makePicture(getMediaPath("Dave_Da_Dapper_Duck.jpg"))
    if player.count("Dave Da Dapper Duck") > 1:
      filename = "Dave_Da_Dapper_Duck" + str(player.count("Dave Da Dapper Duck")) + ".jpg"
      source =  makePicture(getMediaPath(filename))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        color = getColor(getPixel(source,x,y))
        setColor(getPixel(map, x + 750, y + 175), color)
        
def clearItems():
  global map, player
  color = white
  if "firewood" in player:
    source = makePicture(getMediaPath("firewood.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 525, y + 125), color)
  if "food" in player:
    source = makePicture(getMediaPath("food.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 600, y + 125), color)
  if "empty bottle" in player:
    source = makePicture(getMediaPath("empty bottle.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 675, y + 125), color)
  if "water" in player:
    source = makePicture(getMediaPath("water.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 750, y + 125), color)
  if "matches" in player:
    source = makePicture(getMediaPath("matches.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 525, y + 175), color)
  if "key" in player:
    source = makePicture(getMediaPath("key.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 600, y + 175), color)
  if "pages" in player:
    source = makePicture(getMediaPath("pages.jpg"))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 675, y + 175), color)
  if "Dave Da Dapper Duck" in player:      
    source = makePicture(getMediaPath("Dave_Da_Dapper_Duck.jpg"))
    if player.count("Dave Da Dapper Duck") > 1:
      filename = "Dave_Da_Dapper_Duck" + str(player.count("Dave Da Dapper Duck")) + ".jpg"
      source =  makePicture(getMediaPath(filename))
    for x in range(0, getWidth(source)):
      for y in range(0, getHeight(source)):
        setColor(getPixel(map, x + 750, y + 175), color)
        
      
#------------------EDIT SCOREBOARD-------------------------
def writeScore(string):
  list = string.split(":")
  scoreboard = getMediaPath("scoreboard.txt")
  file = open(scoreboard,"rt")
  scores = file.read()
  file.close()

  if scores.endswith("\n") == True:
    scores = scores[:-1]
  scores = scores.split("\n")
  newlist = []
  lower = False
  string = ""
  for item in scores:
    item = item.split(":")
    newlist.append(item)
   
  for item in newlist:
    if list[0] == item[0]:
      if int(list[1]) >= int(item[1]):
        newlist.remove(item)
        newlist.append(list)
        lower = True
        break
      else:
        lower = True
        break
    else:
      continue
      
  if lower == False:
    newlist.append(list)
  for i in range(0,len(newlist)):
    x = ":".join(newlist[i])
    string = string + x + "\n"
  file = open(scoreboard,"wt")
  file.write(string)
  file.close()

def changemap(location):
  showlocation(location)
  showItems()
  playerMarker(location)
  clearlocation(location)
  clearPlayerMarker(location)
  clearItems()
#--------------------DEV EXIT FOR DEBUGGING------------------
def devExit():
  global player, fire, kicthen_unlock, porch_count, hall_count, upper_count, living_count, dining_count, bath_count, kitchen_count, bed_count, patio_count 
  fire = False
  kitchen_unlock = True
  player.append("firewood")
  player.append("food")
  player.append("water")
  player.append("pages") 
  player.append("matches")
  player.append("key")
  player.append("empty bottle")
  porch_count = 2
  hall_count = 2
  upper_count = 2
  living_count = 2 
  dining_count = 2
  bath_count = 2
  kitchen_count = 2 
  bed_count = 2 
  patio_count = 2
  
  
  
  
  


  
  
  
  
  