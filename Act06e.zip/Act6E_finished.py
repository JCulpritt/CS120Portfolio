def downUp(picture_in,picture_out,scale):
  sourceX = 0
  for targetX in range(0,int(getWidth(picture_in)*(1.0/scale))):
    sourceY = 0
    for targetY in range(0,int(getHeight(picture_in)*(1.0/scale))):
      color = getColor(getPixel(picture_in,int(sourceX),int(sourceY)))
      setColor(getPixel(picture_out,targetX,targetY), color)
      sourceY = sourceY + scale
    sourceX = sourceX + scale

def blur(picture_in):
    target=duplicatePicture(picture_in)
    for x in range(1, getWidth(picture_in)-1):
        for y in range(1, getHeight(picture_in)-1):
            top = getPixel(picture_in,x,y-1)
            left = getPixel(picture_in,x-1,y)
            bottom = getPixel(picture_in,x,y+1)
            right = getPixel(picture_in,x+1,y)
            center = getPixel(target,x,y)
            newRed=(getRed(top)+ getRed(left) + getRed(bottom) + getRed(right)+ getRed(center))/5
            newGreen=(getGreen(top) + getGreen(left) + getGreen(bottom)+getGreen(right)+getGreen(center))/5
            newBlue=(getBlue(top) + getBlue(left) + getBlue(bottom) + getBlue(right)+ getBlue(center))/5
            setColor(center, makeColor(newRed, newGreen, newBlue))
    return target

def copyPicture(picture_in,picture_out,target_x,target_y):
  C_target_y = target_y
  for x in range(0, getWidth(picture_in)):
    for y in range(0, getHeight(picture_in)):
      color = getColor(getPixel(picture_in,x,y))
      setColor(getPixel(picture_out,target_x,target_y),color)
      target_y += 1
    target_x += 1
    target_y = C_target_y
  return picture_out
            

def main():
  picture = makePicture(pickAFile())
  canvas = makeEmptyPicture(int(getWidth(picture)*(1.0/2)),int(getHeight(picture)*(1.0/2)))
  explore(picture)
  downUp(picture,canvas,2)
  explore(canvas)
  canvas2 = makeEmptyPicture(getWidth(picture),getHeight(picture))
  downUp(canvas, canvas2, .5)
  explore(canvas2)
  blurred = blur(canvas2)
  explore(blurred)
  canvas3 = makeEmptyPicture(int(getWidth(picture)*.80),int(getHeight(picture)*.80))
  downUp(blurred, canvas3, 1.0/.80)
  explore(canvas3)
  canvas4 = makeEmptyPicture(getWidth(picture),getHeight(picture))  
  explore(copyPicture(canvas3,canvas4,getWidth(canvas2)/10, getHeight(canvas2)/10))
  
 