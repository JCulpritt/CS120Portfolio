pic1 = makePicture(pickAFile())
pic2 = makePicture(pickAFile())
def fourthpixel(source, destipicture, starting):
    for x in range(starting,getWidth(source),2):
        for y in range(starting,getHeight(source),2):
            try:
              setColor(getPixel(destipicture,x,y),getColor(getPixel(source,x,y)))
            except:
              print("Input Error; Pictures must be same Height and Width")
              return            
    return destipicture
def halfandhalf(source, destipicture):
  fourthpixel(source, destipicture,0)
  fourthpixel(source, destipicture,1)
  explore(destipicture)