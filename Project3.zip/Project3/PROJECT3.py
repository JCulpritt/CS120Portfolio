#Joseph A. Culp
#11/06/23
#when testing the code, you will have to set the media path and library path in the console before executing.
from SoundLib import *

def soundCollage():
  soundlist = []
  #OG SOUND
  s1 = makeSound(getMediaPath('thisisatest.wav'))
  soundlist.append(s1)
  
  #Mirror
  mirrored = duplicateSound(s1)
  mirrorSound(mirrored)
  soundlist.append(mirrored)
  
  #Reversed
  reversed = reverse(s1)
  soundlist.append(reversed)
  
  #Lower Frequency
  freqchange = downUp(s1,.5)
  soundlist.append(freqchange)
  
  #Lower Volume
  lower = lowervolume(s1)
  soundlist.append(lower)
  
  #Echo
  echoed = echoes(s1,.25,20)
  soundlist.append(echoed)
  
  #Normalize Volume
  normalized = duplicateSound(s1)
  normalize(normalized)
  soundlist.append(normalized)
  
  #Compile
  count = 0
  FINAL = makeEmptySound(getLength(s1)+getLength(mirrored)+getLength(reversed)+getLength(freqchange)+getLength(lower)+getLength(echoed)+getLength(normalized))
  for i in soundlist:
    copy(i,FINAL,count)
    lengths = getLength(i)
    count += lengths
  print"There are",getDuration(FINAL),"seconds in the FINAL sound"
  explore(FINAL)
    

def downUp(sound_in,scale):
  empty = makeEmptySound(int(getLength(sound_in)*1.0/scale), int(getSamplingRate(sound_in)))
  sourceX = 0
  for targetX in range(0,int(getLength(empty))):
    value = getSampleValueAt(sound_in,int(sourceX))
    setSampleValueAt(empty,targetX,value)
    sourceX += scale
  return empty
  
def lowervolume(s1):
  s2 = duplicateSound(s1)
  for sample in range(0,getLength(s2)):
    setSampleValueAt(s2,sample, getSampleValueAt(s2,sample)*.02)
  return s2

def echoes(s1,seconds,num):
  delay = int(getSamplingRate(s1) * seconds)
  ends1 = getLength(s1)
  ends2 = ends1 + (delay * num)
  s2 = makeEmptySound(ends2)
  
  echoAmplitude = 1.0
  for echoCount in range(0,num):
    echoAmplitude = echoAmplitude * 0.6
    for posns1 in range(0,ends1): 
      posns2 = posns1 + (delay * echoCount)
      values1 = getSampleValueAt(s1,posns1) * echoAmplitude 
      values2 = getSampleValueAt(s2,posns2) 
      setSampleValueAt(s2,posns2,values1 + values2)
  return(s2)
  
def normalize(sound):
  largest = 1
  for s in getSamples(sound):
    largest = max(largest,getSampleValue(s) )
    multiplier = 32767.0 / largest
  for s in getSamples(sound):
    louder = multiplier * getSampleValue(s)
    setSampleValue(s,louder)