setLibPath()
from SoundLib import *

def Lab9():
  setMediaPath()
  wave = sineWave(500,12000,2)
  blockingPlay(wave)
  square = squareWave(500,12000,2)
  blockingPlay(square)
  s1 = makeSound(getMediaPath("airplane.wav"))
  repeated = repeat(s1,5)
  FINAL = echo(5000,repeated)
  explore(FINAL)
  

def echo(delay,s1):
  s2 = duplicateSound(s1)
  for index in range(delay, getLength(s1)):
    # set delay value to original value + delayed value * .6
    echoSample = 0.6*getSampleValueAt(s2, index-delay)
    comboSample = getSampleValueAt(s1,index) + echoSample
    setSampleValueAt(s2, index,comboSample)
  play(s2)
  return s2
  
def sineWave(freq,amplitude,secs):
  buildSin = makeEmptySoundBySeconds(secs)
  sr = getSamplingRate(buildSin) 
  interval = 1.0/freq
  samplesPerCycle = interval * sr
  maxCycle = 2 * pi
  for pos in range (0,getLength(buildSin)):
    rawSample = sin((pos / samplesPerCycle) * maxCycle)
    sampleVal = int(amplitude*rawSample)
    setSampleValueAt(buildSin,pos,sampleVal)
  return buildSin
  
def squareWave(freq,amplitude,seconds):
  # Get a blank sound
  square = makeEmptySoundBySeconds(seconds)
  # Set music constants
  samplingRate = getSamplingRate(square) # sampling rate
  # Build tools for this wave
  # seconds per cycle: make sure floating point
  interval = 1.0 / freq
  # creates floating point since interval is fl point
  samplesPerCycle = interval * samplingRate
  # we need to switch every half-cycle
  samplesPerHalfCycle = int(samplesPerCycle / 2)
  sampleVal = amplitude
  s=1
  i=1
  for s in range (0, getLength(square)):
    # if end of a half-cycle
    if (i > samplesPerHalfCycle):
      # reverse the amplitude every half-cycle
      sampleVal = sampleVal * -1
      # and reinitialize the half-cycle counter
      i=0
    setSampleValueAt(square,s,sampleVal)
    i=i+1
  return(square)

def repeat(s1,num):
  s2 = makeEmptySound(getLength(s1)*(num+1))
  for index in range(0,num+1):
    copy(s1,s2,getLength(s1)*index)
  return s2
  


  

    