def blackBars(picture):
  barWidth = getWidth(picture)/9
  barLine(barWidth,barWidth*2,picture)
  barLine(barWidth*3,barWidth*4,picture)
  barLine(barWidth*5,barWidth*6,picture)
  barLine(barWidth*7,barWidth*8,picture)
  repaint(picture)
def barLine(startX,endX,picture):
  z = startX*2
  for x in range(startX,endX):
    for y in range(0, getHeight(picture)):
      setColor(getPixel(picture,x,y),black)
    z = z + 1

def spreadImage(picture):
  barwidth = getWidth(picture)/5
  canvas = makeEmptyPicture(barwidth*9,getHeight(picture),black)
  repaint(canvas)
  copySlice(0,barwidth,picture,canvas)
  copySlice(barwidth,barwidth*2,picture,canvas)
  copySlice(barwidth*2,barwidth*3,picture,canvas)
  copySlice(barwidth*3,barwidth*4,picture,canvas)
  copySlice(barwidth*4,barwidth*5,picture,canvas)
  repaint(canvas)
def copySlice(startX,endX,picture,canvas):
  z = startX*2
  for x in range(startX, endX):
    for y in range(0, getHeight(picture)):
      color = getColor(getPixel(picture,x,y))
      setColor(getPixel(canvas,z,y),color)
    z = z + 1
    
