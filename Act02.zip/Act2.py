"""1. make user pick file 2. turn that file into image 3. display image 4. make user pick file (sound file) 5. turn file into sound 6. play sound file"""
def pic():
  file = pickAFile()
  image = makePicture(file)
  show(image)
def sound():
  file = pickAFile()
  sound = makeSound(file)
  play(sound)
  
def main():
  pic()
  sound()
  
main()