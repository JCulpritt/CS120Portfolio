from SoundLib import * 

def activity9C(echoDelay,totalEchoes): 
  s1 = makeSound(getMediaPath("car.wav"))
  s2 = makeSound(getMediaPath("airplane.wav"))
  targetSound = makeEmptySound(getLength(s1) + getLength(s2))
  copy(s1,targetSound,0)
  copy(s2,targetSound,getLength(s1))
  echoedSound = echoes(targetSound,echoDelay,totalEchoes)
  mirrorSound(echoedSound)
  blockingPlay(echoedSound)
  explore(echoedSound)

def echoes(s1,seconds,num):
  delay = int(getSamplingRate(s1) * seconds)
  ends1 = getLength(s1)
  ends2 = ends1 + (delay * num)
  s2 = makeEmptySound(ends2)
  
  echoAmplitude = 1.0
  for echoCount in range(0,num):
    echoAmplitude = echoAmplitude * 0.6
    for posns1 in range(0,ends1): 
      posns2 = posns1 + (delay * echoCount)
      values1 = getSampleValueAt(s1,posns1) * echoAmplitude 
      values2 = getSampleValueAt(s2,posns2) 
      setSampleValueAt(s2,posns2,values1 + values2)
  return(s2)
    