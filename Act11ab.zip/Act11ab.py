def Act11ab():
  num = requestInteger("Number of records being entered")
  ClassData = []
  for i in range(0,num):
    record = data()
    ClassData.append(record)
    ClassData.sort()
  for record in ClassData:
      display(record)



def data():
  questions = ["identification number", "name", "major", "GPA", "Exam Score"]
  index = 0
  record = []
  for i in questions:
    answer = requestString("Please enter your " + i + ":")
    if i == "GPA":
      answer = float(answer)
    if i == "Exam Score":
      answer = int(answer)
    if i == "identification number":
      answer = int(answer)
      
    record.append(answer)
  return record
  
def display(record):
  showInformation("ID #: " + str(record[0]) + "\nName: " + record[1] + "\nMajor: " + record[2] + "\nGPA: " + str(record[3]) + "\nExam Score: " + str(record[4]))


    