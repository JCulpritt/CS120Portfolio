pic = makePicture(pickAFile())
def makelighter(pic):
  for x in range(0, getWidth(pic)):
    for y in range(0, getHeight(pic)):
      px = getPixel(pic,x,y)
      color = getColor(px)
      color = makeLighter(color)
      color = makeLighter(color)
      setColor(px,color)
  repaint(pic)

def quarter_mirror(pic):
    width = getWidth(pic)
    mirrorpoint = width // 4
    for y in range(0,getHeight(pic)):
        for x in range(0,mirrorpoint):
            leftPixel = getPixel(pic,x,y)
            rightPixel = getPixel(pic,width - x - 1,y)
            color = getColor(leftPixel)
            setColor(rightPixel,color)
    repaint(pic)


def main(pic):
  show(pic)
  makelighter(pic)
  quarter_mirror(pic)

    
  