setMediaPath()
def act8():
  sound = makeSound(getMediaPath("c4.wav"))
  explore(sound)
  length = getLength(sound)
  loudest = findloudest(sound)
  multiplier = 32767.0 / loudest / (length / 2)
  for sample in range(0,length/2):
    value = getSampleValueAt(sound,sample)
    setSampleValueAt(sound,sample,value*multiplier*sample)
  for sample in range(length/2, length):
    value = getSampleValueAt(sound,sample)
    setSampleValueAt(sound,sample,value*multiplier*(length-sample))
  explore(sound)
  
def findloudest(sound):
  loudest = 0
  for sample in getSamples(sound):
    if getSampleValue(sample) > loudest:
      loudest = getSampleValue(sample)
  return loudest