addLibPath('C:\\Users\\joseph.culp\\Downloads\\ACT9A\\Library\\')
from SoundLib import *
def cScale():
  #Create all notes
  #Copy notes into empty sound to create scale
  #Create a chord and copy into sound
  #Explore the scale and chord
  c = note(261.626)
  d = note(293.665)
  e = note(329.628)
  f = note(349.228)
  g = note(391.995)
  a = note(440.000)
  b = note(493.164)
  c1 = note(523.251)
  chord = createChord(c,e,g)
  empty = makeEmptySound(getLength(c)*9)
  copy(c,empty,getLength(c)*0)
  copy(d,empty,getLength(c)*1)
  copy(e,empty,getLength(c)*2)
  copy(f,empty,getLength(c)*3)
  copy(g,empty,getLength(c)*4)
  copy(a,empty,getLength(c)*5)
  copy(b,empty,getLength(c)*6)
  copy(c1,empty,getLength(c)*7)
  copy(chord,empty,getLength(c)*8)
  
  explore(empty)


def note(freq):
  setMediaPath('C:\Users\joseph.culp\Downloads\ACT9A\WAV Sounds')
  sound = makeSound(getMediaPath('a440.wav'))
  factor = freq/440.0
  return shiftPitch(sound,factor)
  
  
  

def shiftPitch(source, factor):
  #Written by: DL Largent based on Guzial & Ericson E4 Program 119
  #Date written: 10/16/13
  
  #Accepts a sound and a factor and returns a new sound
  #  shifted by the factor from the original sound.
  #  factor > 0 and < 1 will decrease pitch
  #  factor > 1 will increase pitch
  
  target = makeEmptySound(getLength(source))
  source_index = 0
  
  for target_index in range(0, getLength(target)):
    source_value = getSampleValueAt(source, int(source_index))
    setSampleValueAt(target, target_index, source_value)
    source_index = source_index + factor
    if (source_index >= getLength(source)):
      #Start over to allow new sound to be same length as original.
      source_index = 0
  
  return target


def createChord(note1, note2, note3):
  chord = makeEmptySound(getLength(note1))
  for index in range(0,getLength(note1)):
    Value1 = getSampleValueAt(note1,index)
    Value2 = getSampleValueAt(note2,index)
    Value3 = getSampleValueAt(note3,index)
    total = (Value1 + Value2 + Value3)/3
    
    setSampleValueAt(chord,index,total)
  return chord
  