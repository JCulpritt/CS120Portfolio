def removeBlankLines(string):
  while (string.find("\n\n") != -1):      # Replace double end-of-lines with single
      string = string.replace("\n\n","\n")
  if(string.startswith("\n")):            # Remove blank line at start of file
    string = string[1:]
  if(string.endswith("\n")):              # Remove blank line at end of file
    string = string[:len(string) - 1]
  return string

def readData():
  doc = getMediaPath("Lab12.txt")
  file = open(doc, "rt")
  data = file.read()
  file.close()
  return data
  
def getClassData():
  rawdata = removeBlankLines(readData())
  list = rawdata.split("\n")
  for index in range(0,len(list)):
    list[index] = list[index].split(":")
  list.sort()
  return list
  
def showStudent(student):
  found = findStudent(student)
  show(makePicture(getMediaPath(found[3])))
  showInformation("ID: " + found[0] + "\nName: " + found[1] + "\nPercent: " + found[2]) 
  
def findStudent(id):
  list = getClassData()
  student = []
  for i in list:
    if i[0] == id:
      student = i
  return student

def writeData(class_data):
  string = ""
  for i in range(0, len(class_data)):
    x = ":".join(class_data[i])
    string = string + x + "\n" 
  doc = getMediaPath("Lab12.txt") 
  file = open(doc, "wt")
  data = file.write(string)
  file.close()
    
def addStudent():
  data = getClassData()
  id = requestString("Enter ID:")
  name = requestString("Enter Name:")
  percent = requestString("Enter Percent:")
  picture = requestString("Enter Picture File Name:")
  newlist = [id,name,percent,picture]
  data.append(newlist)
  writeData(data)
  

def removeStudent():
  data = getClassData()
  id=requestString("Provide student Id")
  if(findStudent(id) == -1):
    showInformation("Student Id does not exisit.")
  else:
    for student in data:
      if(id == student[0]): 
        answer=requestString("Do you want to delete this student?")
        if answer.upper() == "Y" or answer.upper() == "YES":
          data.remove(student)
          writeData(data)
          showInformation("Student deleted.")
