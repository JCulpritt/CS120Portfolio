def vowel(char):
    if char in "aeiou":
        return True
    else:
        return False

def piglatin(word):
    if word[0] in "yY":
        return word[1:] + word[0] + "ay"
        
    if vowel(word[0]) == True:
        return word + "way"
        
    else: 
        for letter in word:
            if vowel(letter) == True or letter in "yY":
                return word[word.index(letter):]  + word[:word.index(letter)] + "ay"


def readFileData(document):
  file = open(document,"rt")
  contents = file.read()
  file.close()
  return contents

def pTool(word):
  #added this in to unjumble the puncuation in the text
    if str(word).isalpha() == False:
        for letter in word:
            if letter.isalpha() == False:
                word = word[:word.index(letter)] + word[word.index(letter)+1:] + letter
    return word
    
            

def translate():
    final = ""
    document = pickAFile()
    contents = readFileData(document)
    words = contents.split(" ")
    for word in words:
        new = str(pTool(piglatin(word))) + " "
        final = final + new
    return final
print(translate())
    