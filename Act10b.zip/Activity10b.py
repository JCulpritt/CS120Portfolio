ghost = 0
bathcount = 0
sound = makeSound(getMediaPath('thisisatest.wav'))
def adventureStart():
  location = "porch" 
  showIntro()
  options = ["north","east","south","west","help","exit"]
  while (location != "exit"):
   desc = showRoom(location)
   showInformation(str(desc))
   #printNow(desc)
   direction = requestString("What direction would you like to go? Ex:'North'").lower()
   while direction not in options:
     direction = requestString("The direction you chose wasn't valid. Please try again").lower()#If user input isn't an available option, it will ask again.
   printNow("You chose: "+direction)
   location1 = location
   location = pickRoom(direction,location)
   if location == "invalid option. Pick Again":
     showInformation(location)
     location = location1

def showIntro(): 
  printNow("Hello! Welcome to the adventure house! Type 'North', 'East', 'West', or 'South' to move around the house.")
  printNow("To exit the game, just type 'exit'.")
  printNow("If you need the instructions again at any point, please type 'help' instead of a direction.")
  printNow("You walk up to an abandoned house. You have heard stories about this place.")
  printNow("--------------------------------------------------")#For clarity in text area
  
def pickRoom(direction,room):
  if (direction == "exit"):
    printNow("Thank you for playing!")
    return "exit"
  if direction == "help":
    showIntro()
    return room
  #Porch
  if room == "porch":
    if direction == "north":
      return "hall"
    else:
      return "invalid option. Pick Again"
  #breaking hall into 'Upper Hall' and just 'Hall'
  if room == "hall":
    if direction == "north":
      return "upper hall"
    elif direction == "east":
      return "dining room"
    elif direction == "west": 
      return "living room" 
    elif direction == "south":
      return "porch"
    else:
      return "invalid option. Pick Again"
  #Here is the 'Upper Hall' 
  if room == "upper hall": 
    if direction == "west":
      return "bedroom"
    elif direction == "east":
      return "kitchen"
    elif direction == "north":
      return "bath"
    elif direction == "south":
      return "hall"
    else:
      return "invalid option. Pick Again" 
  #Living Room  
  if room == "living room":
    if direction == "east": 
      return "hall"
    else:
      return "invalid option. Pick Again"
  #Dining Room 
  if room == "dining room":
    if direction == "west":
      return "hall" 
    else:
      return "invalid option. Pick Again"
  #Bedroom 
  if room == "bedroom":
    if direction == "east":
      return "upper hall"
    elif direction == "north":
      return "patio"
    else:
      return "invalid option. Pick Again"
  #Kitchen
  if room == "kitchen":
    if direction == "west":
      return "upper hall"
    else:
      return "invalid option. Pick Again"
  #Bathroom 
  if room == "bath":
    if direction == "south":
      return "upper hall"   
    else:
      return "invalid option. Pick Again"
  #Final One, Patio 
  if room == "patio":
    if direction == "south":
      return "bedroom"
    else:
      return "invalid option. Pick Again"
def showRoom(room): #This function gives a small blurb about the area for effect.
  global bathcount
  if room == "porch":
    checkGhost(room)
    return("You are on the Porch.\nThe rocking chairs are moving by themselves, but there is no wind.")
  if room == "hall":
    checkGhost(room)
    return("You are now in the Hall.\nThe chandelier hanging above is swinging, despite the stillness of the air.")
  if room == "upper hall":
    checkGhost(room)
    return("You are now in the Upper Hall.\nThe paintings on the walls feel like their eyes are following you.")
  if room == "living room":
    checkGhost(room)
    return("You are now in the Living Room.\nThe furniture appears new, despite this place being empty for years. ")
  if room == "bedroom":
    checkGhost(room)
    return("You are now in the Bedroom.\n The bed is meticulously made. Like someone made it this morning.")
  if room == "bath":
    checkGhost(room)
    if bathcount == 0:
      play(sound)
      bathcount += 1
    return("You are now in the Bathroom.\nThis room gives you a frightened feeling for some reason. Maybe it would be best to try a different room.")
  if room == "kitchen":
    checkGhost(room)
    return("You are now in the Kitchen.\nAll of the kitcten utensils are organized very neatly.")
  if room == "dining room":
    checkGhost(room)
    return("You are now in the Dining Room.\nThe table and silverware are set for a meal.")
  if room == "patio":
    checkGhost(room)
    return("You are now in the Patio area.\nThe ashtray is full of cigarette butts.")

def checkGhost(room):
  global ghost
  if room == "dining room" and ghost == 0:
    printNow("BOO")
    ghost = 1
  elif room == "kitchen" and ghost == 1:
    printNow("BOO")
    ghost = 2
  elif room == "patio" and ghost == 2:
    printNow("BOO")
    ghost = 0
    
       
    