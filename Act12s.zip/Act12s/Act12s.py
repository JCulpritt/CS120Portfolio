def squirrelCounter():
  data = counter()
  showInformation(formatter(data))
  writer(data)
def openFile(document):
  file = open(document,"rt")
  contents = file.read()
  file.close()
  if contents.endswith("\n") == True:
    contents = contents[:-1]
  return contents
  
def counter():
  contents = openFile(getMediaPath("NYC_Squirrel.txt"))
  newList = contents.split("\n")
  amList = []
  pmList = []
  allList = []
  noneList = []
  for i in newList:
    i = i.split(",")
    if i[4] == "AM":
      amList.append(i)
    if i[4] == "PM":
      pmList.append(i)
    if i[15] == "TRUE" and i[16] == "TRUE" and i[17] == "TRUE" and i[18] == "TRUE" and i[19] == "TRUE":
      allList.append(i)
    if i[15] == "FALSE" and i[16] == "FALSE" and i[17] == "FALSE" and i[18] == "FALSE" and i[19] == "FALSE": 
      noneList.append(i)
  return [len(amList),len(pmList),len(allList),len(noneList)]

def percent(data,index):
  percent = (float(data[index])/float((data[0] + data[1])))*100.0
  return percent

def formatter(data):
  formatted = "Morning squirrels: " + str(data[0]) + " (" + str(percent(data,0)) + "%)\nAfternoon squirrels: " + str(data[1]) + " (" + str(percent(data,1)) + "%)\nBusy squirrels: " + str(data[2]) + " (" + str(percent(data,2)) + "%)\nLazy squirrels: " + str(data[3]) + " (" + str(percent(data,3)) + "%)"
  return formatted
  
def writer(data):
  document = getMediaPath("SquirrelCounts.txt")
  file = open(document,"wt")
  file.write(str(data))
  file.close()
  showInformation("Data written to SquirrelCounts.txt")
