addLibPath('C:\\Users\\JosephC\\Downloads\\Library\\')
from SoundLib import *

def main():
  setMediaPath("C:\Users\JosephC\Downloads\WAV Sounds")
  sound1 = makeSound(getMediaPath('gettysburg.wav'))
  sound2 = makeSound(getMediaPath('preamble.wav'))
  blockingPlay(sound1)
  blockingPlay(sound2)
  final = weave(sound1,sound2)
  explore(final)
  blockingPlay(final)

 
def weave(sound1,sound2):
  canvas = makeEmptySound(getLength(sound1)+getLength(sound2))
  twoSec = int(getSamplingRate(sound1) * 2)
  slicenum = int(getLength(sound2)/ twoSec) +1
  indexGetty = 0
  indexPre = 0
  indexCanvas = 0
  
  for slice in range(0,slicenum):
    ending = indexGetty + twoSec
    if min(ending, getLength(sound1)) < getLength(sound1):
      copyslice(sound1, indexGetty, min(ending, getLength(sound1)),indexCanvas,canvas)
      indexCanvas = indexCanvas + (min(ending, getLength(sound1))-indexGetty)
      indexGetty = min(ending, getLength(sound1))  
    
    ending2 = indexPre + twoSec
    copyslice(sound2, indexPre, min(ending2, getLength(sound2)),indexCanvas,canvas)
    indexCanvas = indexCanvas + (min(ending2, getLength(sound2))-indexPre)
    indexPre = min(ending2, getLength(sound2))
    
  return canvas
  
def copyslice(sound, start, end, target, canvas):
  clipped = clip(sound, start, end)
  copy(clipped, canvas, target)