def sound2pic():
  sound = makeSound(pickAFile())
  picture = makeEmptyPicture(500,500,white)
  soundindex = 0
  for p in getPixels(picture):
    if soundindex == getLength(sound):
      break
    sample = getSampleValueAt(sound, soundindex)
    if sample > -32768 and sample < -15001:
      setColor(p,magenta)
    if sample > -15000 and sample < -5001:
      setColor(p,pink)
    if sample > -5000 and sample < -501:
      setColor(p,blue)
    if sample > -500 and sample < 499:
      setColor(p,green)
    if sample > 500 and sample < 4999:
      setColor(p,yellow)
    if sample > 5000 and sample < 14999:
      setColor(p,orange)
    if sample > 14999 and sample < 32767:
      setColor(p,red)
    soundindex += 1
  return picture

def pic2sound():
  picture = makePicture(pickAFile())
  sound = makeEmptySoundBySeconds(10)
  sndindex = 0
  for p in getPixels(picture):
    if sndindex == getLength(sound):
      break
    color = getRed(p) + getGreen(p) + getBlue(p)
    if color > 0 and color < 199:
      setSampleValueAt(sound,sndindex,2000)
    elif color > 200 and color < 299:
      setSampleValueAt(sound,sndindex,4000)
    elif color > 300 and color < 399:
      setSampleValueAt(sound,sndindex,6000)
    elif color > 400 and color < 499:
      setSampleValueAt(sound,sndindex,-6000)
    elif color > 500 and color < 599:
      setSampleValueAt(sound,sndindex,-4000)
    elif color > 600 and color < 699:
      setSampleValueAt(sound,sndindex,-2000)
    elif color > 700:
      setSampleValueAt(sound,sndindex,0)
    sndindex += 1
  return sound
  
def reverse(pic):
  sound = makeEmptySoundBySeconds(10)
  sndinx = 0
  for p in getPixels(pic):
    color = getColor(p)
    if sndinx == getLength(sound):
      break
    if color == magenta:
        setSampleValueAt(sound, sndinx, (-32768 + -15001)/2)
    elif color == pink:
        setSampleValueAt(sound,sndinx,(-15000 + -5001)/2)
    elif color == blue:
        setSampleValueAt(sound,sndinx,(-5000 + -501)/2)
    elif color == green:
        setSampleValueAt(sound,sndinx,(-500 + 499)/2)
    elif color == yellow:
        setSampleValueAt(sound,sndinx,(500 + 4999)/2)
    elif color == orange:
        setSampleValueAt(sound,sndinx,(5000 + 14999)/2)
    elif color == red:
        setSampleValueAt(sound,sndinx,(15000 + 32767)/2)
    else: 
        setSampleValueAt(sound,sndinx,0)

      
    sndinx += 1
  return sound
  
explore(reverse(sound2pic()))