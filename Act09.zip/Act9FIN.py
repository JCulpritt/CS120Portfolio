def combine():
  setMediaPath('C:\Users\JosephC\Downloads\WAV Sounds')
  preamble = makeSound(getMediaPath("preamble10.wav"))
  c4 = makeSound(getMediaPath("c4.wav"))
  blockingPlay(c4)
  blockingPlay(preamble)
  count = 0
  empty = makeEmptySound(max(getLength(preamble),getLength(c4)))
  for sample in range(0,getLength(c4)):
    setSampleValueAt(c4,sample,getSampleValueAt(c4,sample)*.75)
  for sample in range(0,max(getLength(preamble),getLength(c4))):
    if count >= (min(getLength(preamble), getLength(c4))):
      count = 0
    prevalue = getSampleValueAt(preamble,sample)
    c4value = getSampleValueAt(c4,count)
    count += 1
    setSampleValueAt(empty,sample,prevalue+c4value)
  explore(c4)
  explore(preamble)
  explore(empty)
    
      