pic = makePicture(pickAFile())
def lighter(pic):
  for x in range(0, getWidth(pic)):
    for y in range(0, getHeight(pic)):
      px = getPixel(pic,x,y)
      color = getColor(px)
      color = makeLighter(color)
      color = makeLighter(color)
      setColor(px,color)
  repaint(pic)

def darker(pic):
  for x in range(0, getWidth(pic)):
    for y in range(0, getHeight(pic)):
      px = getPixel(pic,x,y)
      color = getColor(px)
      color = makeDarker(color)
      color = makeDarker(color)
      setColor(px,color)
  repaint(pic)

def quarter_mirror(pic):
    width = getWidth(pic)
    mirrorpoint = width // 4
    for y in range(0,getHeight(pic)):
        for x in range(0,mirrorpoint):
            leftPixel = getPixel(pic,x,y)
            rightPixel = getPixel(pic,width - x - 1,y)
            color = getColor(leftPixel)
            setColor(rightPixel,color)
    repaint(pic)

def quarter_mirror2(pic):
    height = getHeight(pic)
    mirrorpoint = height // 4
    for x in range(0,getWidth(pic)):
        for y in range(0,mirrorpoint):
            topPixel = getPixel(pic,x,y)
            bottomPixel = getPixel(pic,x,height-y-1)
            color = getColor(topPixel)
            setColor(bottomPixel,color)
    repaint(pic)

def waffle():
  canvas = makeEmptyPicture(100,100,yellow)
  verticalLines(canvas)
  horizontalLines(canvas)
  show(canvas)
  return canvas
def horizontalLines(src):
  for x in range(0,getHeight(src),5):
    for y in range(0,getWidth(src)):
      setColor(getPixel(src,y,x),black)
def verticalLines(src):
  for x in range(0,getWidth(src),5):
    for y in range(0,getHeight(src)):
      setColor(getPixel(src,x,y),black)

def main(pic):
  show(pic)
  lighter(pic)
  quarter_mirror(pic)
  quarter_mirror2(pic)
  darker(pic)
  waffle()
  explore(pic)

    
  