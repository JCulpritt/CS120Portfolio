def downUp(picture_in,picture_out,scale):
  sourceX = 0
  for targetX in range(0,int(getWidth(picture_in)*(1.0/scale))):
    sourceY = 0
    for targetY in range(0,int(getHeight(picture_in)*(1.0/scale))):
      color = getColor(getPixel(picture_in,int(sourceX),int(sourceY)))
      setColor(getPixel(picture_out,targetX,targetY), color)
      sourceY = sourceY + scale
    sourceX = sourceX + scale

def main(scale):
  picture = makePicture(pickAFile())
  canvas = makeEmptyPicture(int(getWidth(picture)*(1.0/scale)),int(getHeight(picture)*(1.0/scale)))
  explore(picture)
  downUp(picture,canvas,scale)
  explore(canvas)
 