def blendSounds():
  setMediaPath("C:\Users\joseph.culp\Downloads\WAV Sounds")
  c4 = makeSound(getMediaPath("c4.wav"))
  g4 = makeSound(getMediaPath("g4.wav"))
  length = getLength(c4)
  halfLength = length / 2
  canvas = makeEmptySound(length + halfLength, int(getSamplingRate(c4)))
  recip = 1.0/halfLength
  for index in range(0,halfLength):
    aahSample = getSampleValueAt(c4,index)
    setSampleValueAt(canvas,index,aahSample)
  for index in range(0,halfLength):
    c4Sample = getSampleValueAt(c4,index+halfLength)
    g4Sample=getSampleValueAt(g4,index)
    newSamplec4 = (halfLength - index) * c4Sample * recip
    newSampleg4 = index * g4Sample * recip
    finalSample = newSamplec4 + newSampleg4
    setSampleValueAt(canvas,index + halfLength,finalSample)
  for index in range(halfLength,length):
    g4Sample = getSampleValueAt(g4,index)
    setSampleValueAt(canvas,index + halfLength,g4Sample)
  explore(canvas)