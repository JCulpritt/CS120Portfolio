def asciiName():
  print ord("C"),ord("h"),ord("a"),ord("r"),ord("l"),ord("i"),ord("e")
  
def mathFunc():
  a = 27
  b = 42
  c = ord("D")
  d = 3.14
  
  print str(a) + " added to " +  str(b) + " is equal to " + str(a + b)
  print str(b) + " minus " +  str(c) + " is equal to " + str(b - c)
  print str(d) + " multiplied by " +  str(a) + " is equal to " + str(d * a)
  print str(a) + " divided by " +  str(b) + " is equal to " + str(a/b)
  print str(d) + " divided by " +  str(a) + " is equal to " + str(d / a)
  
def picPicSound():
  pic1 = makePicture(pickAFile())
  pic2 = makePicture(pickAFile())
  sound1 = makeSound(pickAFile())
   
  show(pic1)
  show(pic2)
  play(sound1)
   