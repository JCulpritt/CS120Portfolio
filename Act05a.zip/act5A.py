def luminance(pixel):
  r = getRed(pixel)
  g = getGreen(pixel)
  b = getBlue(pixel)
  return (r+g+b)/3
def edgeDetect(source, threshold):
  for px in getPixels(source):
    x = getX(px)
    y = getY(px)
    if y < getHeight(source)-1 and x < getWidth(source)-1:
      botrt = getPixel(source,x+1,y+1)
      thislum = luminance(px)
      brlum = luminance(botrt)
      if abs(brlum-thislum) > threshold:
        setColor(px,red)
      if abs(brlum-thislum) <= threshold:
        setColor(px,blue)
  show(source)
  
  
def border(source):
  bottom = getHeight(source) - 5
  width = getWidth(source) - 5
  color = pickAColor()
  for px in getPixels(source):
    y = getY(px)
    if y < 5:
      setColor(px, color)
    if y > bottom:
      setColor(px, color)
      
  for px in getPixels(source):
   
    x = getX(px)
    if x < 5:
      setColor(px, color)
    if x > width:
      setColor(px, color)
  
  repaint(source)
  
def main(source, x):
  edgeDetect(source, x)
  border(source)