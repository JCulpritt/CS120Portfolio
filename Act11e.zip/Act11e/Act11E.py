def itemDemo():
  initialization()
  room = "porch"
  while room != "exit":
    pickUpQuestions(room)
    showItems()
    dropQuestions(room)
    showItems()
    room = pickRoom()
    
    
    

def initialization():
  global umbrellaLeft
  global umbrellaRight
  global hall
  global bedroom
  global bathroom
  global kitchen
  global floorplan
  global player
  umbrellaLeft = makePicture(getMediaPath("UmbrellaLeft.jpg"))
  umbrellaRight = makePicture(getMediaPath("UmbrellaRight.jpg"))
  hall = umbrellaLeft
  bedroom = umbrellaRight
  bathroom = ""
  kitchen = ""
  floorplan = makePicture(getMediaPath("Floor Plan.jpg"))
  player = []
  repaint(floorplan)
def pickUpQuestions(room):
  global umbrellaLeft
  global umbrellaRight
  global player
  global hall
  global bedroom
  global bathroom
  global kitchen
  if room == "hall":
    if hall == umbrellaLeft: 
      question = requestString("Do you want to pick up the Left Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaLeft)
        hall = ""
      else:
        showInformation("ok")
    if hall == umbrellaRight: 
      question = requestString("Do you want to pick up the Right Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaRight)
        hall = ""
      else:
        showInformation("ok")
  if room == "bedroom":
    if bedroom == umbrellaLeft: 
      question = requestString("Do you want to pick up the Left Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaLeft)
        bedroom = ""
      else:
        showInformation("ok")
    if bedroom == umbrellaRight: 
      question = requestString("Do you want to pick up the Right Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaRight)
        bedroom = ""
      else:
        showInformation("ok")
  if room == "bathroom":
    if bathroom == umbrellaLeft: 
      question = requestString("Do you want to pick up the Left Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaLeft)
        bathroom = ""
      else:
        showInformation("ok")
    if bathroom == umbrellaRight: 
      question = requestString("Do you want to pick up the Right Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaRight)
        bathroom = ""
      else:
        showInformation("ok")
  if room == "kitchen":
    if kitchen == umbrellaLeft: 
      question = requestString("Do you want to pick up the Left Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaLeft)
        kitchen = ""
      else:
        showInformation("ok")
    if kitchen == umbrellaRight: 
      question = requestString("Do you want to pick up the Right Umbrella?").lower()
      if question == "yes":
        player.append(umbrellaRight)
        kitchen = ""
      else:
        showInformation("ok")
     
  
def showItems():
  global umbrellaLeft
  global umbrellaRight
  global floorplan
  global player
  clearItemAreaOfMap()
  if umbrellaLeft in player:
    copyPicture(umbrellaLeft, floorplan, 450, 100)
  if umbrellaRight in player:
    copyPicture(umbrellaRight, floorplan, 450, 300)
  repaint(floorplan)
  
def clearItemAreaOfMap():
  global floorplan
  for x in range(450, getWidth(floorplan)):
    for y in range(100, getHeight(floorplan)):
      setColor(getPixel(floorplan, x, y), white)

def copyPicture(source, target, targetX, targetY):
  for sourceX in range(0, getWidth(source)):
    for sourceY in range(0, getHeight(source)):
      color = getColor(getPixel(source, sourceX, sourceY))
      setColor(getPixel(target, sourceX+targetX, sourceY+targetY), color)

def dropQuestions(room):
  global umbrellaLeft
  global umbrellaRight
  global player
  global hall
  global bedroom
  global bathroom
  global kitchen
  if room == "hall":
    if umbrellaLeft in player:
      dropLeft = requestString("Do you want to drop the left umbrella?").lower()
      if dropLeft == "yes":
        player.remove(umbrellaLeft)
        hall = umbrellaLeft
    if umbrellaRight in player:
      dropRight = requestString("Do you want to drop the right umbrella?").lower()
      if dropRight == "yes":
        player.remove(umbrellaRight)
        hall = umbrellaRight
  if room == "bedroom":
    if umbrellaLeft in player:
      dropLeft = requestString("Do you want to drop the left umbrella?").lower()
      if dropLeft == "yes":
        player.remove(umbrellaLeft)
        bedroom = umbrellaLeft
    if umbrellaRight in player:
      dropRight = requestString("Do you want to drop the right umbrella?").lower()
      if dropRight == "yes":
        player.remove(umbrellaRight)
        bedroom = umbrellaRight
  if room == "bathroom":
    if umbrellaLeft in player:
      dropLeft = requestString("Do you want to drop the left umbrella?").lower()
      if dropLeft == "yes":
        player.remove(umbrellaLeft)
        bathroom = umbrellaLeft
    if umbrellaRight in player:
      dropRight = requestString("Do you want to drop the right umbrella?").lower()
      if dropRight == "yes":
        player.remove(umbrellaRight)
        bathroom = umbrellaRight
  if room == "kitchen":
    if umbrellaLeft in player:
      dropLeft = requestString("Do you want to drop the left umbrella?").lower()
      if dropLeft == "yes":
        player.remove(umbrellaLeft)
        kitchen = umbrellaLeft
    if umbrellaRight in player:
      dropRight = requestString("Do you want to drop the right umbrella?").lower()
      if dropRight == "yes":
        player.remove(umbrellaRight)
        kitchen = umbrellaRight

def pickRoom():
  room = ""
  while not (room in ["bathroom", "bedroom", "hall", "kitchen", "exit"]):
    room = requestString("Where do you want to go?\n(bathroom, bedroom, hall, kitchen, or exit)")
    room = room.lower()
  return room
