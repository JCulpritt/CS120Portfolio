def chromakey():
  setMediaPath()
  source = makePicture(getMediaPath("Images/FrogBabyOnYellow.jpg"))
  bg = makePicture(getMediaPath("JPG Images/Beach.jpg"))
  for px in getPixels(source):
    x = getX(px)
    y = getY(px)
    if (getRed(px) > 100 and getGreen(px) > 100 and getBlue(px)< 100):
      bgpx = getPixel(bg,x,y)
      bgcol = getColor(bgpx)
      setColor(px,bgcol)
  explore(source)
  posterize(source)
  explore(source)
  
def posterize(pic):
  for p in getPixels(pic):
    r = getRed(p)
    g = getGreen(p)
    b = getBlue(p)
    luminance = (r+g+b)/3
    if luminance < 50:
      setColor(p,black)
    elif 49 < luminance < 166:
      setColor(p, gray)
    else:
      setColor(p,white)
