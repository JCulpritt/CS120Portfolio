setMediaPath()
def RedEyeRemove():
  pic = makePicture(getMediaPath("babyredeye.jpg"))
  explore(pic)
  for px in getPixels(pic):
    x = getX(px)
    y = getY(px)
    if (40 <= x <= 140) and (140 <= y <= 150):
      if (distance(red, getColor(px)) < 165):
        setColor(px, black)
  explore(pic)
  

def RedEyeRemoveScream():
  pic = makePicture(getMediaPath("screamingchild.jpg"))
  explore(pic)
  for px in getPixels(pic):
    x = getX(px)
    y = getY(px)
    if (190 <= x <= 333) and (250 <= y <= 265):
      if (distance(red, getColor(px)) < 150):
        setColor(px, black)
  explore(pic)
  
def tone():
  pic = makePicture(pickAFile())
  explore(pic)
  for px in getPixels(pic):
    chromakey = (getRed(px) + getBlue(px) + getGreen(px)) / 3
    setColor(px, makeColor(chromakey, chromakey, chromakey))
    if getBlue(px) < 63:
      setBlue(px, (getBlue(px) * 2))
    if getBlue(px) > 62 and getBlue(px) < 192:
      setBlue(px, (getBlue(px) * 1.3))
    if getBlue(px) > 191:
      setBlue(px, (getBlue(px) * 1.2))
    setRed(px, getRed(px) * .75)
    setGreen(px, getGreen(px) * .75)
  explore(pic)
  