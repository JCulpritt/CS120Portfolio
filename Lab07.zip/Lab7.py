
def normalize(sound):
  largest = 1
  for s in getSamples(sound):
    largest = max(largest,getSampleValue(s) )
    multiplier = 32767.0 / largest
  for s in getSamples(sound):
    louder = multiplier * getSampleValue(s)
    setSampleValue(s,louder)
  
    
def downUp(sound_in,scale):
  empty = makeEmptySound(int(getLength(sound_in)*1.0/scale), int(getSamplingRate(sound_in)))
  sourceX = 0
  for targetX in range(0,int(getLength(empty))):
    value = getSampleValueAt(sound_in,int(sourceX))
    setSampleValueAt(empty,targetX,value)
    sourceX += scale
  return empty
    
def main():
  setMediaPath("C:\Users\joseph.culp\Downloads\WAV Sounds")
  sound = makeSound(getMediaPath("yesterday.wav"))
  blockingPlay(sound)
  low = downUp(sound,.5)
  explore(low)
  high = downUp(sound,1.75)
  explore(high)
  normalize(high)
  explore(high)
  
  
  
