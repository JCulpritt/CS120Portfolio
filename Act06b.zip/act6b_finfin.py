pic = makePicture(pickAFile())

def spreadImage(picture, barnum):
  barwidth = getWidth(picture)/barnum
  canvas = makeEmptyPicture(barwidth*(barnum*2-1),getHeight(picture),black)
  for slice in range(0, barnum):
    copySlice(barwidth*slice,barwidth*(slice+1),picture,canvas)
  repaint(canvas)
  
def copySlice(startX,endX,picture,canvas):
  z = startX*2
  for x in range(startX, endX):
    for y in range(0, getHeight(picture)):
      color = getColor(getPixel(picture,x,y))
      setColor(getPixel(canvas,z,y),color)
    z = z + 1
    
