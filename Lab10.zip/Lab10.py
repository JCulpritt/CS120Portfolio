from random import randint
def Play():
  player = intro().lower().capitalize()
  again = "1"
  while again == "1":
    flag = game()
    if flag == "win":
      printNow("CONGRATULATRIONS "+ player + "! YOU WON!!")
    if flag == "lose":
      printNow("Welp, you'll get them next time " + player + "!!")
    again = requestString("Would you like to play again??!\n 1 for yes. 2 for no.")
    if again == "1":
      printNow("YIPPEE LETS PLAYY!!!")
    elif again == "2":
      printNow("alrighty... have a wonderful day!!!")
    else:
      printNow("I'm gonna take that as a no... :(")
  


def intro():
  printNow("Welcome to OH CRAPS! the worlds best craps game simulator!!")
  name = requestString("Can I get a name for you?")
  return name
  
def game():
  flag = "continue"
  win = [7,11]
  lose = [2, 3, 12]
  while flag == "continue":
    dice1 = randint(1,6)
    dice2 = randint(1,6)
    sum = dice1 + dice2
    printNow("first dice: " + str(dice1) + "\nsecond dice: " + str(dice2) + "\nsum: " + str(sum) + "\n")
    if sum in win:
      flag = "win"
      return flag
    elif sum in lose:
      flag = "lose"
      return flag
    else:
      point = sum
      lose = win
      while flag == "continue":
        dice1 = randint(1,6)
        dice2 = randint(1,6)
        sum = dice1 + dice2
        printNow("first dice: " + str(dice1) + "\nsecond dice: " + str(dice2) + "\nsum: " + str(sum) + "\n")
        if sum == point:
          flag = "win"
          return flag
        if sum in lose:
          flag = "lose"
          return flag
    
        
            
        
      
  

