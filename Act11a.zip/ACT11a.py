def GetFile():
  gettysburg = open(pickAFile(), "rt")
  lines = gettysburg.read()
  gettysburg.close()
  return lines

def Specs(lines):
  lines = lines.replace("\n\n","\n")
  paras = lines.count("\n")
  sentences = lines.count(".")
  words = lines.count(" ")
  chars = len(lines)
  return "-----FILE STATISTICS-----\nParagraphs: " + str(paras) + "\nSentences: " + str(sentences) + "\nWords: " + str(words) + "\nCharacters: " + str(chars) + "\n\n"
  
def prepend():
  file = open(pickAFile(),"wt")
  gettysburg = GetFile()
  file.write(Specs(gettysburg))
  file.write(gettysburg)
  file.close()
 
  
