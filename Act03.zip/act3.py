def act3(name):
  counter = 1
  for index in range(0, len(name)):
    print(name[index]*counter)
    counter += 1
  counter = len(name)
  for index in range(0, len(name)):
    print(name[index]*counter)

    counter = counter - 1

act3("david")

  