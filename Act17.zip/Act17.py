def shape(sides):
  w = makeWorld()
  t = makeTurtle(w)
  if sides > 2:
    angle = (360/sides)
    dis = 500/sides
    if rect == 0:
      for i in range(0,sides):
        forward(t, dis)
        turn(t, angle)
  

def right():
  w = makeWorld()
  t = makeTurtle(w)
  forward(t,100)
  turn(t,135)
  forward(t,142)
  turn(t,135)
  forward(t,100)
  turn(t,90)

def rect():
  w = makeWorld()
  t = makeTurtle(w)
  forward(t,100)
  turn(t,90)
  forward(t,150)
  turn(t,90)
  forward(t,100)
  turn(t,90)
  forward(t,150)