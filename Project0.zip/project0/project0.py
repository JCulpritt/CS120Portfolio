def ceasercipher(encoded):
    encoded = encoded.upper()
    alpha = ".,!? ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for shift in range(0, len(alpha)):
        decoded = ""
        for letter in encoded:
            findindex = alpha.find(letter)
            alphaindex = findindex - shift
            decodedletter = alpha[alphaindex]
            decoded += decodedletter
        print(decoded)


ceasercipher("E.DKLA.UKQ.AJFKUA .SNEPEJC.PDEO.LNKCN,IW. E .UKQ.BEJ .EP.D,N .PK.snepaz")
            
    