def wordfun(string):
  pile = ""
  for index in range(len(string)-1, -1, -1):
    pile += string[index]
  for index in range(0, len(string)):
    print string[index].upper()
    print pile[index].lower()
    
def madlib(name, number, color):
  print "Once upon a time there was a programmer named " + name + ". Their favorite color was " + color + " and they wanted " + str(number) + " of their favorite things. However, " + name + " was " + str(number * 5) + " years old, so they didn't get everything they wanted." 

