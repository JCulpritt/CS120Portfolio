def getClassData():
  raw_data = readFileData()
  class_list = raw_data.split("\n")
  class_list.sort()
  class_data = []
  for student in class_list:
    student = student.split(":")
    class_data = class_data + [[student[0], student[1].split(",")]]
  return class_data


def printOneStudent(student):
    report_line = student[0]
    total = 0
    for score in student[1]:
      total = total + int(score)
      report_line = report_line + "\t" + score
    print report_line + "\t" + str(total) + "\t" + str(total / 4.0)


def readFileData():
  document = pickAFile()
  file = open(document,"rt")
  contents = file.read()
  file.close()
  return contents
  
def printHeadings():
  print "Name\tQ1\tQ2\tQ3\tQ4\tTot\tAvg\n"

def reportAllStudents():
  printHeadings()
  for student in getClassData():
     printOneStudent(student)
     
def reportOneStudent(name):
  for student in getClassData():
    if student[0] == name:
       printHeadings()
       printOneStudent(student)
       final = ""
       break
    else:
      final = "Student does not exist"
      
  print final
  
  
  
  
  
  
  