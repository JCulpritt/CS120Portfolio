
def scaleDown(picture_in,picture_out):
  sourceX = 0
  for targetX in range(0,getWidth(picture_in)/2):
    sourceY = 0
    for targetY in range(0,getHeight(picture_in)/2):
      color = getColor(getPixel(picture_in,sourceX,sourceY))
      setColor(getPixel(picture_out,targetX,targetY), color)
      sourceY = sourceY + 2
    sourceX = sourceX + 2   
  
  
  
def scaleUp(picture_in,picture_out):
  sourceX = 0
  for targetX in range(0,getWidth(picture_in)*2):
    sourceY = 0
    for targetY in range(0,getHeight(picture_in)*2):
      color = getColor(getPixel(picture_in,int(sourceX),int(sourceY)))
      setColor(getPixel(picture_out,targetX,targetY), color)
      sourceY = sourceY + 0.5
    sourceX = sourceX + 0.5 

def main():
  picture = makePicture(pickAFile())
  small_picture = makeEmptyPicture(getWidth(picture)/2,getHeight(picture)/2)
  big_picture = makeEmptyPicture(getWidth(small_picture)*2,getHeight(small_picture)*2)
  explore(picture)
  scaleDown(picture,small_picture)
  explore(small_picture)
  scaleUp(small_picture,big_picture)
  explore(big_picture)