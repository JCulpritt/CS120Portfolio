picture = makePicture(pickAFile())
canvas = makeEmptyPicture(getWidth(picture),getHeight(picture))

def shuffle_a2b(pic,canvas):
  for x in range(0,getWidth(pic)/2):
    for y in range(0,getHeight(pic)/2):
      color = getColor(getPixel(pic,x,y))
      setColor(getPixel(canvas,x+getWidth(pic)/2,y),color)
  return canvas
  
def shuffle_b2c(pic,canvas):
  for x in range(getWidth(pic)/2,getWidth(pic)):
    for y in range(0,getHeight(pic)/2):
      color = getColor(getPixel(pic,x,y))
      setColor(getPixel(canvas,x,y+getHeight(pic)/2),color)
  return canvas

def shuffle_c2d(pic,canvas):
  for x in range(getWidth(pic)/2,getWidth(pic)):
    for y in range(getHeight(pic)/2,getHeight(pic)):
      color = getColor(getPixel(pic,x,y))
      setColor(getPixel(canvas,x-getWidth(pic)/2,y),color)
  return canvas

def shuffle_d2a(pic, canvas):
  for x in range(0,getWidth(pic)/2):
    for y in range(getHeight(pic)/2,getHeight(pic)):
      color = getColor(getPixel(pic,x,y))
      setColor(getPixel(canvas,x,y-getHeight(pic)/2),color)
  return canvas
  
def Lab6(pic,canvas):
  shuffle_a2b(pic, canvas)
  shuffle_b2c(pic, canvas)
  shuffle_c2d(pic, canvas)
  shuffle_d2a(pic, canvas)
  show(canvas)