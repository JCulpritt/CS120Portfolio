pic = makePicture(pickAFile())

def act4b(pic):
  show(pic)
  changeColor(pic)
  makeSquare(pic)
  fillIn(pic)
  explore(pic)

def changeColor(pic):

  pixels = getPixels(pic)
  color = pickAColor()
  
  for p in pixels:
    setColor(p, color)
    
  repaint(pic)
  
def makeSquare(pic):
  color = pickAColor()
  width = getWidth(pic)
  pixels=getPixels(pic)
  setColor(pixels[0], color)
  setColor(pixels[1], color)
  setColor(pixels[2], color)
  setColor(pixels[3], color)
  setColor(pixels[4], color)
  setColor(pixels[5], color)
  setColor(pixels[6], color) 
  setColor(pixels[width], color)
  setColor(pixels[width + 6], color)
  setColor(pixels[width * 2], color)
  setColor(pixels[width * 2 + 6], color)
  setColor(pixels[width * 3], color)
  setColor(pixels[width * 3 + 6], color)
  setColor(pixels[width * 4], color)
  setColor(pixels[width * 4 + 6], color)
  setColor(pixels[width * 5], color)
  setColor(pixels[width * 5 + 6], color)
  setColor(pixels[width * 6], color)
  setColor(pixels[width * 6 + 1], color)
  setColor(pixels[width * 6 + 2], color)
  setColor(pixels[width * 6 + 3], color)
  setColor(pixels[width * 6 + 4], color)
  setColor(pixels[width * 6 + 5], color)
  setColor(pixels[width * 6 + 6], color)
  
  repaint(pic)
  
def fillIn(pic):
  color = pickAColor()
  width = getWidth(pic)
  pixels = getPixels(pic)
  
  for p in range(width + 1, width + 6):
    setColor(pixels[p], color)
   
  for p in range(width * 2 + 1, width * 2 + 6):
    setColor(pixels[p], color)
    
  for p in range(width * 3 + 1, width * 3 + 6):
    setColor(pixels[p], color)
    
  for p in range(width * 4 + 1, width * 4 + 6):
    setColor(pixels[p], color)
    
  for p in range(width * 5 + 1, width * 5 + 6):
    setColor(pixels[p], color)
    
  repaint(pic)
 