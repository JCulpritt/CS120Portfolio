#Joseph A. Culp
#10/20/2023
setMediaPath("C:\Users\JosephC\Downloads\Project2")
def collage():
  #collage uses all functions below dotted line
  pic = makePicture("Fragment2.jpg")
  bigcanvas = makeEmptyPicture(int(1000*.8),int(736*.8),black)
  #defines what each "slice" is. Important because it is proportionate to size of image
  slice = finalscale(pic,bigcanvas)
  DL = halfandhalf(slice,duplicatePicture(slice))
  INV = inverted(slice,duplicatePicture(slice))
  GRE = grayscale(slice,duplicatePicture(slice))
  POS = posterize(slice,duplicatePicture(slice))
  #copies above slices onto a canvas 20% smaller than Final Canvas
  copyslice(DL,bigcanvas,getHeight(slice)*0)
  copyslice(INV,bigcanvas,getHeight(slice)*1)
  copyslice(GRE,bigcanvas,getHeight(slice)*2)
  copyslice(POS,bigcanvas,getHeight(slice)*3)
  copyslice(slice,bigcanvas,getHeight(slice)*4)
  #creates final canvas
  FINAL = makeEmptyPicture(1000,736,black)
  #splits and spreads four pieces
  crosshair(bigcanvas,FINAL)
  #applies signature
  chromesig(FINAL)
  show(FINAL)
  
def finalscale(picin,canvas):
  #scales images to the size of the final slices
  propx = float(getWidth(canvas))/float(getWidth(picin))
  propy = (float(getHeight(canvas))/float(getHeight(picin)))/5.0
  newcan = downUpY(picin,canvas,propy)
  picout = downUpX(newcan,canvas,propx)   
  return picout
def copyslice(picin,picout,C_starty):
  #copys the final slices into a canvas (picout)
  starty = C_starty
  for x in range(0,getWidth(picin)):
    for y in range(0,getHeight(picin)):
      color = getColor(getPixel(picin,x,y))
      setColor(getPixel(picout,x,starty),color)
      starty += 1
    starty = C_starty
def chromesig(picin):
  #applies signature onto image
  signature = makePicture(getMediaPath("signature5.jpeg"))
  for x in range(0,getWidth(signature)):
    for y in range(0,getHeight(signature)):
      if getRed(getPixel(signature,x,y)) < 150 and getGreen(getPixel(signature,x,y)) < 150 and getBlue(getPixel(signature,x,y)) < 175:
        color = makeColor(218,165,32)
        setColor(getPixel(picin,x,y),color)
  return picin
  
def darker(picin,picout):
  #makes first half of image darker
  for x in range(0, getWidth(picin)/2):
    for y in range(0, getHeight(picin)):
      px = getPixel(picin,x,y)
      px2 = getPixel(picout,x,y)
      color = getColor(px)
      color = makeDarker(color)
      color = makeDarker(color)
      setColor(px2,color)
  return picout
def lighter(picin,picout):
  #makes last half of image lighter
  for x in range(getWidth(picin)/2, getWidth(picin)):
    for y in range(0, getHeight(picin)):
      px = getPixel(picin,x,y)
      px2 = getPixel(picout,x,y)
      color = getColor(px)
      color = makeLighter(color)
      color = makeLighter(color)
      setColor(px2,color)
  return picout
def halfandhalf(picin,picout):
  #combines above two functions to make and image have darker and half lighter
  darker(picin,picout)
  lighter(picin,picout)
  return picout

def inverted(picin,picout):
    #inverts colors
    for x in range(0, getWidth(picin)):
        for y in range(0, getHeight(picin)):
            pixel = getPixel(picin,x,y)
            r = getRed(pixel)
            newr = 255 - int(r)
            g = getGreen(pixel)
            newg = 255 - int(g)
            b = getBlue(pixel)
            newb = 255 - int(b)
            setColor(getPixel(picout,x,y),makeColor(newr,newg,newb))
    return picout

def grayscale(picin,picout):
    #turns image into gray scale
    for x in range(0, getWidth(picin)):
        for y in range(0, getHeight(picin)):
            pixel = getPixel(picin,x,y)
            r = getRed(pixel)
            g = getGreen(pixel)
            b = getBlue(pixel)
            avg = (r+g+b)/3
            setColor(getPixel(picout,x,y),makeColor(avg,avg,avg))
    return picout


def posterize(picin,picout):
    #posterizes image
    for x in range(0, getWidth(picin)):
        for y in range(0, getHeight(picin)):
            r = getRed(getPixel(picin,x,y))
            g = getGreen(getPixel(picin,x,y))
            b = getBlue(getPixel(picin,x,y))
            luminance = (r+g+b)/3
            if luminance < 50:
                setColor(getPixel(picout,x,y),black)
            elif 49 < luminance < 166:
                setColor(getPixel(picout,x,y), gray)
            else:
                setColor(getPixel(picout,x,y),white)
    return picout

def crosshair(pic,canvas):
    #combines the four functions below this one
    copy_quad1(pic,canvas)
    copy_quad2(pic,canvas)
    copy_quad3(pic,canvas)
    copy_quad4(pic,canvas)
    return canvas

def copy_quad1(picin,picout):
    #moves topright quarter of pic in to topright of larger canvas
    for x in range(0, getWidth(picin)/2):
        for y in range(0, getHeight(picin)/2):
            setColor(getPixel(picout,x,y),getColor(getPixel(picin,x,y)))
    return picout
def copy_quad2(picin,picout):
    #moves topright quarter of pic in to topright of larger canvas
    altx = getWidth(picout) - getWidth(picin)/2
    for x in range(getWidth(picin)/2,getWidth(picin)):
         for y in range(0,getHeight(picin)/2):
           color = getColor(getPixel(picin,x,y))
           setColor(getPixel(picout,altx,y),color)
         altx += 1
    repaint(picout) 
    return picout
def copy_quad3(picin,picout):
  #moves bottomleft quarter of pic to bottomleft of larger canvas
  alty = getHeight(picout) - getHeight(picin)/2
  for x in range(0,getWidth(picin)/2):
    for y in range(getHeight(picin)/2,getHeight(picin)):
      color = getColor(getPixel(picin,x,y))
      setColor(getPixel(picout,x,alty),color)
      alty += 1
    alty = getHeight(picout) - getHeight(picin)/2
  return picout
def copy_quad4(picin,picout):
  #moves bottomright quarter of pic to bottomright of larger canvas
  alty = getHeight(picout) - getHeight(picin)/2
  altx = getWidth(picout) - getWidth(picin)/2
  for x in range(getWidth(picin)/2,getWidth(picin)):
    for y in range(getHeight(picin)/2,getHeight(picin)):
      color = getColor(getPixel(picin,x,y))
      setColor(getPixel(picout,altx,alty),color)
      alty += 1 
    altx += 1
    alty = getHeight(picout) - getHeight(picin)/2
  return picout

    
def downUpY(picin,canvas,scale):
  #scales image down or up on the Y axis
  picout = makeEmptyPicture(getWidth(picin),getHeight(canvas)/5)
  for x in range(0,getWidth(picin)):
    alty = 0
    for y in range(0,int(getHeight(picin)*scale)):
      color = getColor(getPixel(picin,x,int(alty)))
      setColor(getPixel(picout,x,y), color)
      alty += 1.0/scale
  return picout
    
def downUpX(picin,canvas,scale):
  #scales image down or up on the X axis
  altx = 0
  picout = makeEmptyPicture(getWidth(canvas),getHeight(picin))
  for x in range(0,int(getWidth(picin)*scale)):
    for y in range(0,getHeight(picin)):  
      color = getColor(getPixel(picin,int(altx),y))
      setColor(getPixel(picout,x,y), color) 
    altx += 1.0/scale
  return picout
    
    


